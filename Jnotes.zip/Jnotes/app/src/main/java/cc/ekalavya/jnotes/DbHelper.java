package cc.ekalavya.jnotes;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
//Importing Constants
import static cc.ekalavya.jnotes.Constants.CREATE_TB;
import static cc.ekalavya.jnotes.Constants.DB_NAME;
import static cc.ekalavya.jnotes.Constants.DB_VERSION;
import static cc.ekalavya.jnotes.Constants.DROP_TB;
import static cc.ekalavya.jnotes.Constants.NOTE;
import static cc.ekalavya.jnotes.Constants.TB_NAME;
import static cc.ekalavya.jnotes.Constants.TITLE;
import static cc.ekalavya.jnotes.Constants.TRUNCATE_TB;
import static cc.ekalavya.jnotes.Constants.rowid;

public class DbHelper extends SQLiteOpenHelper {
    private Context c;
    private SQLiteDatabase database;
    public DbHelper(Context c){
        super(c,DB_NAME,null,DB_VERSION);
        this.c = c;
    }

    public void deleteDB(){

        try {
            SQLiteDatabase database =  this.getWritableDatabase();
            database.execSQL(TRUNCATE_TB);
        }catch (SQLException e){
            e.printStackTrace();
        }
    }//deleteDB

    private void closeDB(){
        try{
            database.close();
        }catch (SQLException e){
            e.printStackTrace();
        }
    }

    public Cursor retrive(){
        Cursor c=null;
        SQLiteDatabase database = getReadableDatabase();
        try {
            String[] columns = {rowid,NOTE,TITLE};
            c = database.query(TB_NAME,columns,null,null,null,null,null);
        }catch (SQLException e){
            e.printStackTrace();
        }
        return c;
    }

    public boolean updateTitle(int itemId,String updateTitle){
        try{
            database = getReadableDatabase();
            ContentValues cv = new ContentValues();
            cv.put(TITLE,updateTitle);
            String whereClause = "rowid=?";
            String[] whereArgs = {""+itemId};
            int rowAffected = database.update(TB_NAME,cv,whereClause,whereArgs);
            if (rowAffected>0)
                return true;
        }catch (SQLException e){
            e.printStackTrace();
        }
        closeDB();
        return false;
    }

    public boolean addItem(String noteTital, String note){
        try{
            database = getReadableDatabase();
            ContentValues cv = new ContentValues();
            cv.put(TITLE,noteTital);
            cv.put(NOTE,note);
            long rowId =database.insert(TB_NAME,null,cv);
            if(rowId>0)
                return true;
        }catch (SQLException e){
            e.printStackTrace();
        }
        return false;
    }

    public boolean updateItem(int itemId,String updatedData){
        try{
            database = getReadableDatabase();
            ContentValues cv = new ContentValues();
            cv.put(NOTE,updatedData);
            String whereClause = "rowid=?";
            String[] whereArgs = {""+itemId};
            int rowAffected = database.update(TB_NAME,cv,whereClause,whereArgs);
            if (rowAffected>0)
                return true;
        }catch (SQLException e){
            e.printStackTrace();
        }
        closeDB();
        return false;
    }

    public boolean deleteItem(int itemId){
        try{
            database = getWritableDatabase();
           String whereClause = "rowid =?";
            String[] whereArgue = {""+itemId};
            int res = database.delete(TB_NAME,whereClause,whereArgue);
            if(res>0)
                return true;
        }catch (SQLException e){
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TB);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(DROP_TB);
        db.execSQL(CREATE_TB);
    }
}
