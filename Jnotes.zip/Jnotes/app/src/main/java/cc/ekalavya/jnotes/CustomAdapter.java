package cc.ekalavya.jnotes;

import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;


public class CustomAdapter extends ArrayAdapter<SingleNote>{
    Context context;
    ArrayList<SingleNote> notes;
    LayoutInflater inflater;
    TextView t1,t2;
    String note,noteTitle;

    public CustomAdapter(Context context, ArrayList<SingleNote> notes){
        super(context,R.layout.single_not,notes);
        this.notes = notes;
        this.context = context;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        int wordCount=0;
        boolean fcf=false;          //fcf=first character found
        StringBuilder glimpse = new StringBuilder();

        //inflate layout
        if (inflater == null)
            inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if (convertView == null)
            convertView = inflater.inflate(R.layout.single_not, parent, false);

        t1 = convertView.findViewById(R.id.title);
        t2 = convertView.findViewById(R.id.note);
        t1.setTextColor(Color.rgb(234,240,241));
        t2.setTextColor(Color.rgb(208,216,223));
        try{
            note = notes.get(position).getNote();
            noteTitle = notes.get(position).getNoteTitle();
        }catch (NullPointerException e){
            e.printStackTrace();
        }
        t1.setText(noteTitle);
        //code to make list view text generic( NO space, new line considered, directly note from first alphabet is considered)
        note = note.replaceAll("\\n\\r|\\n|\\r", "");
        if (note.length() > 60) {
            for(int i =0;i<note.length()-1;i++){
                if(wordCount>=18)
                    break;
                char c = note.charAt(i);
                if (fcf){
                    glimpse.append(c);
                }else {
                    if(c!=' ') {
                        fcf=true;
                        glimpse.append(c);
                    }
                }
                if(c ==' ' && note.charAt(i+1)!=' ') {
                    wordCount++;
                }
            }//for
            t2.setText(glimpse);
        }//if
        else {
            t2.setText(note);
        }
        return convertView;
    }
}