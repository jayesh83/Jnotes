package cc.ekalavya.jnotes;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.facebook.stetho.Stetho;

import java.util.ArrayList;

import static cc.ekalavya.jnotes.Constants.NOTE;
import static cc.ekalavya.jnotes.Constants.TITLE;
import static cc.ekalavya.jnotes.Constants.rowid;

public class MainActivity extends AppCompatActivity {
    ListView lv;
    AlertDialog.Builder builder;
    static ArrayList<SingleNote> arrayList;
    static CustomAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Stetho.initializeWithDefaults(this);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        lv = findViewById(R.id.lv);
        FloatingActionButton fab = findViewById(R.id.fab);
        //fab.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.colorAccent)));    //fab button bgrnd to white
        arrayList = new ArrayList<>();
        builder = new AlertDialog.Builder(this);
            Thread thread = new Thread(new Runnable() {
                @Override
                public void run() {
                    getNotes();
                }
            });
            thread.start();
            adapter = new CustomAdapter(this,arrayList);
            lv.setAdapter(adapter);
            lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Intent intent = new Intent(MainActivity.this, NoteEditor.class);
                    intent.putExtra("noteId",position);
                    startActivity(intent);
                }
            });
            lv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener(){
                @Override
                public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, final long id) {
                    builder.setMessage("Do you want to delete?")
                            .setCancelable(false)
                            .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    DbHelper dbHelper = new DbHelper(MainActivity.this);
                                    boolean deleted = dbHelper.deleteItem(arrayList.get(position).getNoteId());
                                    if(deleted)
                                    {
                                        MainActivity.arrayList.remove(arrayList.get(position));
                                        MainActivity.adapter.notifyDataSetChanged();
                                    }
                                    else{
                                        Toast.makeText(MainActivity.this, "Not deleted", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            })
                            .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.cancel();
                                        }
                                    });
                    AlertDialog alertDialog = builder.create();
                    alertDialog.setTitle("Delete note");
                    alertDialog.show();
                    return true;
                }
            });

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, NoteEditor.class);
                startActivity(intent);
            }
        });


    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    private void getNotes(){
        SingleNote singleNote;
        MainActivity.arrayList.clear();
        DbHelper db = new DbHelper(this);
        //db.deleteDB();
            Cursor c = db.retrive();
        //Taking index number of columns in DB
            int idIndex = c.getColumnIndex(rowid);
            int noteIndex = c.getColumnIndex(NOTE);
            int titleIndex = c.getColumnIndex(TITLE);

        while (c.moveToNext()){
            singleNote = new SingleNote();
            int id = c.getInt(idIndex);
            String note = c.getString(noteIndex);
            String noteTitle = c.getString(titleIndex);
            singleNote.setNoteId(id);
            singleNote.setNote(note);
            singleNote.setNoteTitle(noteTitle);
            MainActivity.arrayList.add(singleNote);
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.aboutMe) {
            Intent intent = new Intent(this,AbouteMe.class);
            startActivity(intent);
            }
        else if(id == R.id.deleteDb){
            builder.setMessage("Caution! All notes will be deleted\nSure want to delete all notes?")
                    .setTitle("Delete all")
                    .setCancelable(false)
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            MainActivity.arrayList.clear();
                            adapter.notifyDataSetChanged();
                            DbHelper db = new DbHelper(MainActivity.this);
                            db.deleteDB();
                        }
                    })
                    .setNegativeButton("No Don't", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                        }
                    });
            AlertDialog dialog = builder.create();
            dialog.show();
        }
        return super.onOptionsItemSelected(item);
    }
}
