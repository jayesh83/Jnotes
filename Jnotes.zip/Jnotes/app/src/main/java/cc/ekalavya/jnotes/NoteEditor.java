package cc.ekalavya.jnotes;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.Toast;

import static cc.ekalavya.jnotes.MainActivity.adapter;


public class NoteEditor extends AppCompatActivity {
    EditText editor_view,titleView;
    int position,noteId,noteType=0;
    boolean dataChanged=false,titleChanged=false,isTitleNull=false,isContentNull = false,newNote=false;
    DbHelper dbHelper = new DbHelper(this);
    SingleNote singleNote;
    String oldNote,noteString,titleString,oldTitle;
    CharSequence charS,titleChar;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_editor);
        editor_view = findViewById(R.id.editor_view);
        titleView = findViewById(R.id.editText1);
        Intent receivedIntent = getIntent();
        position = receivedIntent.getIntExtra("noteId", -1);
        if (position != -1) {
            //intent came through onItemClickListener in a listView
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
            noteId = MainActivity.arrayList.get(position).getNoteId();
            oldNote = MainActivity.arrayList.get(position).getNote();
            oldTitle = MainActivity.arrayList.get(position).getNoteTitle();
            //set views
            editor_view.setText(oldNote);
            titleView.setText(oldTitle);
            noteType=0;
        } else {
            //intent came through fab button( new note )
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
            MainActivity.arrayList.add(null);
            position = MainActivity.arrayList.size()-1;
            newNote = true;
            noteType=1;
        }
        titleView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                titleChanged = true;
                titleChar = s;
            }
            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        editor_view.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                //we simply want to keep it blank...
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                dataChanged = true;     //used to create toast saying data changed...
                charS = s;
            }

            @Override
            public void afterTextChanged(Editable s) {
                //we simply want to keep it blank...
            }
        });
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        if(charS!=null)
            noteString = charS.toString();
        if (titleChar!=null)
            titleString = titleChar.toString();
                switch (noteType){      //0 means old and 1 means new note
                    case 0:
                        if(titleChanged&&dataChanged){
                            isTitleNull = checkTitleNull(titleString);
                            isContentNull = checkNoteNull(noteString);

                            if(isTitleNull&&isContentNull){
                                MainActivity.arrayList.remove(position);
                                adapter.notifyDataSetChanged();
                                boolean deleted = dbHelper.deleteItem(noteId);
                                if(deleted)
                                    Toast.makeText(this, "Deleted!", Toast.LENGTH_SHORT).show();
                                break;
                            }

                            if(isTitleNull||isContentNull){
                                if(isTitleNull){
                                    if(!isContentNull){
                                        singleNote = new SingleNote();
                                        titleString = extractTitle(noteString);
                                        singleNote.setNote(noteString);
                                        singleNote.setNoteTitle(titleString);
                                        singleNote.setNoteId(noteId);
                                        MainActivity.arrayList.set(position,singleNote);
                                        adapter.notifyDataSetChanged();
                                        //Update in DB
                                            boolean updated = updateInDb(noteId,titleString,noteString);
                                        if(updated)Toast.makeText(this, "Updated", Toast.LENGTH_SHORT).show();
                                        break;
                                    }
                                }
                                if(isContentNull){
                                    if(!isTitleNull){
                                        singleNote = new SingleNote();
                                        titleString = filterTitle(titleString);
                                        singleNote.setNoteTitle(titleString);
                                        singleNote.setNote("");
                                        singleNote.setNoteId(noteId);
                                        MainActivity.arrayList.set(position,singleNote);
                                        adapter.notifyDataSetChanged();
                                        //Update in DB
                                        boolean updated = updateInDb(noteId,titleString,"");
                                        if(updated)Toast.makeText(this, "Updated", Toast.LENGTH_SHORT).show();
                                        break;
                                    }
                                }
                            }
                            else{
                                //filter title before adding
                                singleNote = new SingleNote();
                                titleString = filterTitle(titleString);
                                singleNote.setNoteTitle(titleString);
                                singleNote.setNote(noteString);
                                singleNote.setNoteId(noteId);
                                MainActivity.arrayList.set(position,singleNote);
                                adapter.notifyDataSetChanged();
                                //Update in DB
                                    boolean updated = updateInDb(noteId,titleString,noteString);
                                if(updated)Toast.makeText(this, "Updated", Toast.LENGTH_SHORT).show();
                                break;
                            }
                            break;
                        }//firstCondition
                        if(titleChanged||dataChanged){
                            if (titleChanged){
                                if(titleString.contentEquals("")){
                                    if (oldNote.contentEquals("")) {
                                        MainActivity.arrayList.remove(position);
                                        adapter.notifyDataSetChanged();
                                        boolean deleted = dbHelper.deleteItem(noteId);
                                        if(deleted)Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show();
                                        break;
                                    }else
                                        titleString = extractTitle(oldNote);
                                }
                                else
                                    titleString = filterTitle(titleString);
                                singleNote = new SingleNote();
                                singleNote.setNote(oldNote);
                                singleNote.setNoteTitle(titleString);
                                singleNote.setNoteId(noteId);
                                MainActivity.arrayList.set(position,singleNote);
                                adapter.notifyDataSetChanged();
                                //Update in DB
                                    boolean updated = dbHelper.updateTitle(noteId,titleString);
                                if(updated)Toast.makeText(this, "Updated", Toast.LENGTH_SHORT).show();
                                break;
                            }
                            if(dataChanged){
                                singleNote = new SingleNote();
                                singleNote.setNoteId(noteId);
                                singleNote.setNoteTitle(oldTitle);
                                singleNote.setNote(noteString);
                                MainActivity.arrayList.set(position,singleNote);
                                adapter.notifyDataSetChanged();
                                //Update in DB
                                     boolean updated = dbHelper.updateItem(noteId,noteString);
                                if(updated)Toast.makeText(this, "Updated", Toast.LENGTH_SHORT).show();
                                break;
                            }
                            break;
                        }//second Condition
                            break;
                    case 1:
                        if(titleChanged&&dataChanged){
                            isTitleNull = checkTitleNull(titleString);
                            isContentNull = checkNoteNull(noteString);

                            if(isTitleNull&&isContentNull){
                                MainActivity.arrayList.remove(position);
                                adapter.notifyDataSetChanged();
                                Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show();
                                break;
                            }

                            if(isTitleNull||isContentNull){
                                if(isTitleNull){
                                    if(!isContentNull){
                                        singleNote = new SingleNote();
                                        titleString = extractTitle(noteString);
                                        //Add in DB
                                            boolean added = dbHelper.addItem(titleString,noteString);
                                        singleNote.setNote(noteString);
                                        singleNote.setNoteTitle(titleString);
                                        fetchNoteId();
                                        singleNote.setNoteId(noteId);
                                        MainActivity.arrayList.set(position,singleNote);
                                        adapter.notifyDataSetChanged();
                                        if(added)Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
                                    }
                                    break;
                                }
                                if(isContentNull){
                                    if(!isTitleNull){
                                        singleNote = new SingleNote();
                                        titleString = filterTitle(titleString);
                                        singleNote.setNoteTitle(titleString);
                                        singleNote.setNote("");
                                        //add in DB
                                            boolean added = dbHelper.addItem(titleString,"");
                                        fetchNoteId();
                                        singleNote.setNoteId(noteId);
                                        MainActivity.arrayList.set(position,singleNote);
                                        adapter.notifyDataSetChanged();
                                        if(added)Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
                                    }
                                    break;
                                }
                            }
                            else{
                                singleNote = new SingleNote();
                                //filter title before adding
                                titleString = filterTitle(titleString);
                                singleNote.setNoteTitle(titleString);
                                singleNote.setNote(noteString);
                                //Add in DB
                                    boolean added = dbHelper.addItem(titleString,noteString);
                                fetchNoteId();
                                singleNote.setNoteId(noteId);
                                MainActivity.arrayList.set(position,singleNote);
                                adapter.notifyDataSetChanged();
                                if(added)Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
                                break;
                            }
                            break;
                        }//firstCondition

                        if(titleChanged||dataChanged){
                            if (titleChanged){
                                if(titleString.contentEquals("")){
                                    MainActivity.arrayList.remove(position);
                                    adapter.notifyDataSetChanged();
                                }else {
                                    singleNote = new SingleNote();
                                    titleString = filterTitle(titleString);
                                    singleNote.setNoteTitle(titleString);
                                    singleNote.setNote("");
                                    //add in DB
                                        boolean added = dbHelper.addItem(titleString,"");
                                    fetchNoteId();
                                    singleNote.setNoteId(noteId);
                                    MainActivity.arrayList.set(position,singleNote);
                                    adapter.notifyDataSetChanged();
                                    if(added)Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
                                }
                                break;
                            }
                            if(dataChanged){
                                if(checkNoteNull(noteString)){
                                    MainActivity.arrayList.remove(position);
                                    adapter.notifyDataSetChanged();
                                }else{
                                    singleNote = new SingleNote();
                                    titleString = extractTitle(noteString);
                                    singleNote.setNote(noteString);
                                    singleNote.setNoteTitle(titleString);
                                    // Add in DB
                                        boolean added = dbHelper.addItem(titleString,noteString);
                                    fetchNoteId();
                                    singleNote.setNoteId(noteId);
                                    MainActivity.arrayList.set(position,singleNote);
                                    adapter.notifyDataSetChanged();
                                    if(added)Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
                                }
                                break;
                            }
                        }//second Condition
                        else {
                            MainActivity.arrayList.remove(position);
                            adapter.notifyDataSetChanged();
                            break;
                        }
                        newNote=false;
                        break;
                }//noteType switch

    }

    private boolean updateInDb(int id, String title, String notePassed){
        boolean titalUpdated = dbHelper.updateTitle(id,title);
        boolean noteUpdated = dbHelper.updateItem(id,notePassed);
        if(titalUpdated&&noteUpdated)
            return true;
        return false;
    }
    private boolean checkTitleNull(String title){
        return filterTitle(title).contentEquals("");
    }

    private boolean checkNoteNull(String note){
        return filterNote(note).contentEquals("");
    }

    private String extractTitle(String str){
        String s;
        str = str.trim();
        str = str.replaceAll("//r//n|//n|//r","");
        if(str.length()>90){
            s = str.substring(0,90);
        }else
            s = str;
        return s;
    }

    private String filterTitle(String str){
        return str.trim();
    }

    private String filterNote(String note){
        return note.replaceAll("\\r\\n|\\r|\\n|\\s", "");
    }

    private void fetchNoteId(){
        Cursor c = dbHelper.retrive();
        if (c.moveToLast()) {
            noteId = c.getInt(c.getColumnIndex("rowid"));
        }
    }

    @Override
    protected void onDestroy() {
        dbHelper.close();
        super.onDestroy();
    }
}
