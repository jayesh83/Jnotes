package cc.ekalavya.jnotes;

public class Constants {

    //DB columns
    public static final String rowid = "rowid";
    public static final String NOTE= "note";
    public static final String TITLE = "noteTitle";

    //DB properties
    public static final String TB_NAME = "notes";
    public static final String DB_NAME = "Notes";
    public static int DB_VERSION = 2;

    //CREATE STMNT
    public static final String CREATE_TB = "CREATE TABLE IF NOT EXISTS notes(note VARCHAR2, noteTitle VARCHAR2);";
    //DROP TABLE STMNT
    public  static final String DROP_TB = "DROP TABLE notes";

    //TRUNCATE TABLE STMNT
    public  static final String TRUNCATE_TB = "DELETE FROM notes";

}