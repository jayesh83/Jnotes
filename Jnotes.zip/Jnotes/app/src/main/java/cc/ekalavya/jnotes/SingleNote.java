package cc.ekalavya.jnotes;

public class SingleNote {
    private int noteId;
    private String note;
    private String noteTitle;

    public String getNoteTitle() {
        return this.noteTitle;
    }

    public void setNoteTitle(String noteTitle) {
        this.noteTitle = noteTitle;
    }

    public int getNoteId() {
        return this.noteId;
    }

    public String getNote() {
        return this.note;
    }

    public void setNoteId(int noteId) {
        this.noteId = noteId;
    }

    public void setNote(String note) {
        this.note = note;
    }
}

